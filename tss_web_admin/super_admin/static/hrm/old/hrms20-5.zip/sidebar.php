<div class="topbar-left">
    <a href="index.php" class="logo">
        <i>
            <img src="images/fav.png" alt="">
        </i>
    </a>
</div>

<div id="sidebar-menu" class="sidaber_menu">
    <ul class="" id="side-menu">
        <li>
            <p class="splnav"> <i class="fa fa-home"></i>
                <a> Home </a>
            </p>
        </li>
        <li>
            <p class="splnav"> <i class="fa fa-user"></i>
                <a> Self Service </a>
            </p>

            <div class="sidebar_sub_division">
                <ul class="nav_second_sub">
                    <li><a href="#/">Profile</a>
                    </li>
                    <li><a href="leav.php">Absence Management</a>
                    </li>

                </ul>
            </div>

        </li>
        <li>
            <a href="#/"> <i class="fa fa-calendar"></i>
                <p>Leave Tracker</p>
            </a>
        </li>
        <li>
            <a href="employee-master.php"> <i class="fa fa-user-circle"></i>
                <p>Employee Master</p>
            </a>
        </li>
        <li>
            <a href="#/"> <i class="fa fa-clock-o"></i>
                <p>Time Tracker</p>
            </a>
        </li>
        <li>
            <p class="splnav"> <i class="fa fa-trophy"></i>
                <a> Performance </a>
            </p>
            <div class="sidebar_sub_division">
                <ul class="nav_second_sub">
                    <li><a href="appraisal-view.php">Appraisee View</a>
                    </li>
                    <li><a href="#">Goals</a>
                    </li>
                    <li><a href="#">Employee Salary</a>
                    </li>
                    <li class="crnt"><a data-toggle="collapse" href="#Settings" aria-controls="collapseExample"> Settings </a>
                    </li>
                    <ul class="nav_second_sub collapse submnu" id="Settings">
                        <li><a href="skill-set.php">Skill Set</a>
                        </li>
                        <li><a href="competencty.php">Competency</a>
                        </li>
                        <li><a href="summery.php">Summery</a>
                        </li>
                    </ul>
                </ul>
            </div>
        </li>

        <li>
            <p class="splnav"> <i class="fa fa-ellipsis-h"></i>
                <a> More </a>
            </p>
            <div class="sidebar_sub_division">
                <ul class="nav_second_sub">
                    <li><a href="#/">Dummy Text</a>
                    </li>

                </ul>
            </div>
        </li>


        <li class="bootm_toggle_settings_button ">
            <p class="splnav bdr_btmnone_nav"> <i class="fa fa-cog"></i>
                <a> Settings </a>
            </p>
            <div class="sidebar_sub_division">
                <ul class="nav_second_sub">
                    <li class="crnt"><a data-toggle="collapse" href="#Organization" aria-controls="collapseExample"> Organization </a>
                    </li>
                    <ul class="nav_second_sub collapse submnu" id="Organization">

                        <li><a href="user.php">Users</a>
                        </li>
                        <li><a href="department.php">Department</a>
                        </li>
                        <li><a href="designation.php">Designation</a>
                        </li>
                        <!--<li><a href="location.php">Loactions</a>
                        </li>-->
                        <li><a href="location.php">Delegations</a>
                        </li>

                    </ul>
                    <li class="crnt"><a data-toggle="collapse" href="#User-Access" aria-controls="collapseExample"> User Access </a>
                    </li>
                    <ul class="nav_second_sub collapse submnu" id="User-Access">
                        <li><a href="new-role.php">Roles</a>
                        </li>
                      <!--  <li><a href="permision.php">Permisions</a>
                        </li>-->
                    </ul>
            </div>
        </li>


    </ul>
</div>

<!--- Sidemenu -->
<!--<div id="sidebar-menu" class="sidaber_menu">

    <ul class="metismenu" id="side-menu">

        <li> <a>  <i class="fa fa-dashboard"></i>  <p> Dashboard </p>  </a>
            <div class="sidebar_sub_division">
                <ul class="nav_second_sub">
                    <li class="crnt"><a  href="index.php">  Home </a> </li>
                </ul>
            </div>
        </li>
        <li>
            <a>
                <i class="fa fa-dashboard"></i>
                <p> Self-Service </p>
            </a>
            <div class="sidebar_sub_division">

                <p><a href="employee-master.php"> Employee Master </a></p>
                <p><a href="profile.php"> Profile </a></p>
            </div>
        </li>
        <li>
            <a href="employee-master.php">
                <i class="fa fa-user"></i>
                <p> Employee Master </p>
            </a>
        </li>


        <li class="bootm_toggle_settings_button ">
            <p class="splnav bdr_btmnone_nav"><i class="fa fa-cog"></i>
                <a> Settings </a>
            </p>
            <div class="sidebar_sub_division">
                <ul class="nav_second_sub">
                    <li class="crnt"><a data-toggle="collapse" href="#Organization" aria-controls="collapseExample">
                            Organization </a>
                    </li>
                    <ul class="nav_second_sub collapse submnu" id="Organization">

                        <li><a href="employee-master.php"> Employee Master </a></li>
                        <li><a href="profile.php"> Profile </a></li>
                        <li><a href="employee-master.php">
                                <i class="fa fa-user"></i>
                                <p> Employee Master </p>
                            </a></li>


                    </ul>
                    <li class="crnt"><a data-toggle="collapse" href="#User-Access" aria-controls="collapseExample"> User
                            Access </a>
                    </li>
                    <ul class="nav_second_sub collapse submnu" id="User-Access">
                        <li><a href="new-role.php">Roles</a>
                        </li>
                        <li><a href="permision.php">Permisions</a>
                        </li>
                    </ul>
            </div>
        </li>


    </ul>


</div>-->
<!-- Sidebar -->
<div class="bootm_toggle_button">
    <i class="fa fa-align-right"></i>

</div>
