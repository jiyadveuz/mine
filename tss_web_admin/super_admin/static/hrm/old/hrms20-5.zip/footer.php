<!--<footer class="footer">
    <ul class="footaernav">
        <a href="settings.php">
            <li class=""><i class="fa fa-cog" data-toggle="tooltip" title="" data-original-title="Settings"></i></li>
        </a>
        <a id="add_new" class="add_new">
            <li class="" data-toggle="tooltip" title="" data-original-title="Sticky Notes"><i class="fa fa-sticky-note"></i></li>
        </a>
        <a href="">
            <li class=""><i class="fa fa-plus" data-toggle="tooltip" title="" data-original-title="Add"></i></li>
        </a>
    </ul>
</footer>


<div class="add-note">
    <input name="title" id="title" maxlength="50" placeholder="Title"/>
    <textarea name="text" id="text" cols="25" rows="5" placeholder="Text"></textarea>
    <button class="btn btn-info">Add</button>
</div>

<div class="wrap">
</div>

<script id="entry-template" type="text/x-handlebars-template">
    <div class="mainbar">
        <span>{{title}}</span>
        <div class="closesticky"><i class="fa fa-times-circle fa-fw"></i></div>
        <div class="minimize"><i class="fa fa-minus-square-o fa-fw"></i></div>
    </div>
    <pre class="text">{{text}}</pre>
</script>
-->
<script src="js/jquery.min.js"></script>
<script src="js/custome.js"></script>
<!--<script src='js/handlebars.min.js'></script>-->
<!--<script src="js/sticky.js"></script>-->
<!--<script src="js/main.js"></script>-->
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/metisMenu.min.js"></script>
<!--<script src="js/waves.js"></script>-->
<script src="js/jquery.slimscroll.js"></script>
<!--<script src="js/morris.min.js"></script>
<script src="js/raphael-min.js"></script>
<script src="js/jquery.morris.init.js"></script>-->

<!--<script src="js/bootstrap-filestyle.min.js" type="text/javascript"></script>-->
<script src="js/moment.js"></script>
<script src="js/bootstrap-timepicker.js"></script>
<!--<script src="js/bootstrap-colorpicker.min.js"></script>-->
<!--<script src="js/bootstrap-datepicker.min.js"></script>-->
<!--<script src="js/jquery.form-pickers.init.js"></script>-->
<!--<script src="js/bs_settngsnavi.js"></script>-->
<!--<script src="js/kanban.js"></script>-->
<!--[if IE]>
<![endif]-->

<script src="js/bootstrap-datetimepicker.min.js"></script>
<script src="js/moment.js"></script>

<script src="js/select2.full.js"></script>
<script src="js/select2-custome.js"></script>
<!---->
<script src="js/jquery.core.js"></script>
<script src="js/jquery.app.js"></script>
<!--
<script src="js/jquery.min.js"></script>
<script src="js/custome.js"></script>
<script src='js/handlebars.min.js'></script>
<script src="js/sticky.js"></script>

<script src="js/main.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/metisMenu.min.js"></script>
<script src="js/waves.js"></script>
<script src="js/jquery.slimscroll.js"></script>



<script src="js/morris.min.js"></script>
<script src="js/raphael-min.js"></script>
<script src="js/jquery.morris.init.js"></script>

<script src="js/bootstrap-filestyle.min.js" type="text/javascript"></script>
<script src="js/moment.js"></script>
<script src="js/bootstrap-timepicker.js"></script>
<script src="js/bootstrap-colorpicker.min.js"></script>
<script src="js/bootstrap-datepicker.min.js"></script>
<script src="js/jquery.form-pickers.init.js"></script>
<script src="js/bs_settngsnavi.js"></script>
<script src="js/kanban.js"></script>
<!--[if IE]>
<![endif]-->
<script>
    let eleBtnStart = document.querySelector("#btnStart");
    let eleBtnStop = document.querySelector("#btnStop");
    let eleTimer = document.querySelector("#divTimer");

    let timeTicker = (() => {
        var hours = minutes = seconds = 0;
        var timerTick;
        return {
            start : () => {
                if(!timerTick) {
                    timerTick = setInterval(() => {
                        seconds++;
                        if(seconds == 60) {
                            minutes += 1;
                            seconds = 0;
                            if(minutes == 60) {
                                hours += 1;
                                minutes = 0;
                            }
                        }
                        eleTimer.innerHTML = `
${hours.toString().length == 1 ? "0" + hours : hours}
: ${minutes.toString().length == 1 ? "0" + minutes:minutes} Hrs`;
                    },25);
                }
            },
            stop : () => {
                if(timerTick) {
                    clearInterval(timerTick);
                    timerTick = false;
                }
            },
            reset : () => {
                seconds = minutes = hours = 0;
                clearInterval(timerTick);
                timerTick = false;
                eleTimer.innerHTML = `0${hours}:0${minutes}  Hrs`;
            }
        }
    })();
 eleBtnStart.addEventListener('click', () => {
        timeTicker.start();
    });
    eleBtnStop.addEventListener('click', () => {
        timeTicker.stop();
    });

    $('#btnStart').click(function (){
        $(this).closest('.timer').addClass('timer_actv')
    });
    $('#btnStop').click(function (){
        $(this).closest('.timer').removeClass('timer_actv')
    });

    $('.timerbtn_start').click(function (){
        $(this).addClass('disnone_timer')
        $(this).siblings('.timerbtn').addClass('timerbtn_stop');
        $(this).parent().siblings('.divTimer').addClass('divTimer_dsplay')

    });
    $('.timerbtn_stop').click(function (){
        $(this).removeClass('timerbtn_stop')
        $(this).siblings('.timerbtn').removeClass('disnone_timer');
        $(this).parent().siblings('.divTimer').removeClass('divTimer_dsplay')
    });


</script>

<script src="js/jquery.core.js"></script>
<script src="js/jquery.app.js"></script>
<!-- App js -->
<script src="js/select2.full.js"></script>
<script src="js/select2-custome.js"></script>
-->
