<?php include('header.php') ?>
<link href="css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
</head>
<body class="">
<div id="wrapper">
    <div class="left side-menu">
        <div class="slimscroll-menu" id="remove-scroll">
            <?php include('sidebar.php') ?>
            <div class="clearfix"></div>
        </div>
    </div>
    <div class="content-page ">
        <?php include('topnav.php') ?>
        <!-- Start Page content -->
        <div class="content ">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="box_header">
                            <div class="row">
                                <div class="col-md-7 col-12">
                                    <div class="mainiconbox"><i class="fa fa-user"></i>
                                    </div>
                                    <h4 class="m-t-0 header-title">
                                        <div class="breadcrumbs ng-scope">
                                            <ul>
                                                <li><a href="index.php">Home</a></li>
                                                <li><a>Employee</a></li>
                                            </ul>
                                            <div>Employee Name</div>
                                        </div>
                                    </h4>
                                </div>
                            </div>
                        </div>
                        <div class="card-box ">
                            <div class="col-12 p-t-15">
                                <form>
                                    <h4 data-toggle="collapse" href="#basic" class="sub_hdng_edit"><i
                                                class="fa fa-chevron-down"></i> Basic Detaiils</h4>
                                    <div id="basic" class="panel-collapse collapse show">
                                        <div class="m-t-30 m-b-15 acrdn_panel">
                                            <div class="row">
                                                <div class="col-md-6 colp_r_15">
                                                    <div class="form-group">
                                                        <div class="form-group bmd-form-group required_item">
                                                            <input type="text" class="input form-control">
                                                            <label class="inputText">First Name</label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 colp_l_15">
                                                    <div class="form-group">
                                                        <div class="form-group bmd-form-group required_item">
                                                            <input type="text" class="input form-control">
                                                            <label class="inputText">Last Name</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6 colp_r_15">
                                                    <div class="row">
                                                        <div class="col-lg-8 col-md-7 col-sm-8">
                                                            <div class="form-group">
                                                                <div class="form-group bmd-form-group required_item">
                                                                    <input type="text" class="input form-control">
                                                                    <label class="inputText">Job Tittle</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-4 col-md-5 col-sm-4">
                                                            <div class="form-group">
                                                                <div class="form-group bmd-form-group">
                                                                    <select class="slect select2" id="#sclecct">
                                                                        <option>50</option>
                                                                        <option>51</option>
                                                                        <option>52</option>
                                                                        <option>53</option>
                                                                    </select>
                                                                    <label class="inputText openselect2">Pay Grade
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 colp_l_15">
                                                    <div class="row">
                                                        <div class="col-lg-7 col-md-6 col-sm-8">
                                                            <div class="form-group">
                                                                <div class="form-group bmd-form-group required_item">
                                                                    <select class="slect select2">
                                                                        <option>Administration</option>
                                                                        <option>Engineering</option>
                                                                        <option>Finance</option>
                                                                        <option>Human Resources</option>
                                                                        <option>Information Technology</option>
                                                                        <option>Legal</option>
                                                                        <option>Operations</option>
                                                                        <option>Purchasing/Materials</option>
                                                                    </select>
                                                                    <label class="inputText openselect2">Job Family
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-5 col-md-6 col-sm-4">
                                                            <div class="form-group">
                                                                <div class="form-group bmd-form-group">
                                                                    <div class='input-group date'>
                                                                        <input type='text' class="input form-control" id='datetimepicker1' />
                                                                        <span class="input-group-addon">
                                                         <i class="fa fa-calendar"></i>
                                                         </span>
                                                                        <label class="inputText">Date of Joining</label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6 colp_r_15">
                                                    <div class="form-group">
                                                        <div class="form-group bmd-form-group required_item">
                                                            <input type="text" class="input form-control">
                                                            <label class="inputText openselect2">Manager's Name</label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 colp_l_15">
                                                    <div class="row">
                                                        <div class="col-lg-6 col-md-6 col-sm-6">
                                                            <div class="form-group">
                                                                <div class="form-group bmd-form-group required_item">
                                                                    <select class="slect select2">
                                                                        <option>Belgium</option>
                                                                        <option>Brazil</option>
                                                                        <option>Czech Republic</option>
                                                                        <option>Denmark</option>
                                                                        <option>France</option>
                                                                        <option>Germany</option>
                                                                        <option>Holland</option>
                                                                        <option>India</option>
                                                                    </select>
                                                                    <label class="inputText openselect2">Country Location
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-6 col-md-6 col-sm-6">
                                                            <div class="form-group">
                                                                <div class="form-group bmd-form-group required_item">
                                                                    <select class="slect select2">
                                                                        <option>Jan 2010 - Dec 2010</option>
                                                                        <option>Jan 2011 - Dec 2011</option>
                                                                        <option>Jan 2011 - Dec 2012</option>
                                                                        <option>Jan 2011 - Dec 2013</option>
                                                                        <option>Jan 2011 - Dec 2014</option>
                                                                        <option>Jan 2011 - Dec 2015</option>
                                                                        <option>Jan 2011 - Dec 2016</option>
                                                                        <option>Jan 2011 - Dec 2017</option>
                                                                        <option>Jan 2011 - Dec 2018</option>
                                                                        <option>Jan 2011 - Dec 2019</option>
                                                                    </select>
                                                                    <label class="inputText openselect2">Appraisal Period
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6 colp_r_15">
                                                    <div class="form-group">
                                                        <div class="form-group bmd-form-group required_item">
                                                            <select class="slect select2">
                                                                <option>Corporate Headquarters</option>
                                                                <option>Harsco Industrial</option>
                                                                <option>Harsco Infrastructure</option>
                                                                <option>Harsco Metals</option>
                                                                <option>Harsco Metals</option>
                                                                <option>Harsco Minerals</option>
                                                                <option>Harsco Rail</option>
                                                            </select>
                                                            <label class="inputText openselect2">Business Group</label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 colp_l_15">
                                                    <div class="row">
                                                        <div class="col-lg-7 col-md-6 col-sm-8">
                                                            <div class="form-group">
                                                                <div class="form-group bmd-form-group required_item">
                                                                    <select class="slect select2">
                                                                        <option>Corporate</option>
                                                                        <option>Brazil</option>
                                                                        <option>Industrial - Air-X-Changers</option>
                                                                        <option>Industrial - IKG</option>
                                                                        <option>Industrial - Patterson-Kelley</option>
                                                                    </select>
                                                                    <label class="inputText openselect2">Business Unit
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-5 col-md-6 col-sm-4">
                                                            <div class="form-group">
                                                                <div class="form-group bmd-form-group">
                                                                    <div class='input-group date'>
                                                                        <input type='text' class="input form-control" id='datetimepicker2' />
                                                                        <span class="input-group-addon">
                                                         <i class="fa fa-calendar"></i>
                                                         </span>
                                                                        <label class="inputText openselect2">Appraisal Date
                                                                        </label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                    <h4 data-toggle="collapse" href="#work" class="sub_hdng_edit"><i class="fa fa-chevron-down"></i> Work Detaiils</h4>
                                    <div id="work" class="panel-collapse collapse show ">
                                        <div class="m-t-30 m-b-15 col-12">
                                            <div class="row">
                                                <div class="col-md-6 colp_r_15">
                                                    <div class="row">
                                                        <div class="col-lg-6 col-md-6 col-sm-6">
                                                            <div class="form-group">
                                                                <div class="form-group bmd-form-group ">
                                                                    <input type="text" class="input form-control">
                                                                    <label class="inputText">Department</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-6 col-md-6 col-sm-6">
                                                            <div class="form-group">
                                                                <div class="form-group bmd-form-group">
                                                                    <input type="text" class="input form-control">
                                                                    <label class="inputText">Location</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 colp_l_15">
                                                    <div class="row">
                                                        <div class="col-lg-7 col-md-7 col-sm-7">
                                                            <div class="form-group">
                                                                <div class="form-group bmd-form-group ">
                                                                    <select class="slect select2">
                                                                        <option>Corporate Headquarters</option>
                                                                        <option>Harsco Industrial</option>
                                                                        <option>Harsco Infrastructure</option>
                                                                        <option>Harsco Metals</option>
                                                                        <option>Harsco Metals</option>
                                                                        <option>Harsco Minerals</option>
                                                                        <option>Harsco Rail</option>
                                                                    </select>
                                                                    <label class="inputText openselect2">Reporting To
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-5 col-md-5 col-sm-5">
                                                            <div class="form-group">
                                                                <div class="form-group bmd-form-group">
                                                                    <input type="text" class="input form-control">
                                                                    <label class="inputText openselect2">Title</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6 colp_r_15">
                                                    <div class="row">
                                                        <div class="col-lg-8 col-md-7 col-sm-6">
                                                            <div class="form-group">
                                                                <div class="form-group bmd-form-group ">
                                                                    <input type="text" class="input form-control">
                                                                    <label class="inputText">Source of Hire</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-4 col-md-5 col-sm-6">
                                                            <div class="form-group">
                                                                <div class="form-group bmd-form-group">
                                                                    <div class="input-group date">
                                                                        <input type="text" class="input form-control" id="joiningDate">
                                                                        <span class="input-group-addon"> <i
                                                                                    class="fa fa-calendar"></i> </span>
                                                                        <label class="inputText">Date of Joining</label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 colp_l_15">
                                                    <div class="row">
                                                        <div class="col-lg-8 col-md-7 col-sm-6">
                                                            <div class="form-group">
                                                                <div class="form-group bmd-form-group ">
                                                                    <div class="form-group bmd-form-group">
                                                                        <input type="text" class="input form-control">
                                                                        <label class="inputText ">Work Location</label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-4 col-md-5 col-sm-6">
                                                            <div class="form-group">
                                                                <div class="form-group bmd-form-group">
                                                                    <select class="form-control">
                                                                        <option>Active</option>
                                                                        <option>Active</option>
                                                                        <option>Active</option>
                                                                    </select>
                                                                    <label class="inputText">Employee Status</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6 colp_r_15">
                                                    <div class="row">
                                                        <div class="col-lg-5 col-md-12 col-sm-12">
                                                            <div class="form-group">
                                                                <div class="form-group bmd-form-group ">
                                                                    <select class="slect select2">
                                                                        <option>Corporate Headquarters</option>
                                                                        <option>Harsco Industrial</option>
                                                                        <option>Harsco Infrastructure</option>
                                                                        <option>Harsco Metals</option>
                                                                        <option>Harsco Metals</option>
                                                                        <option>Harsco Minerals</option>
                                                                        <option>Harsco Rail</option>
                                                                    </select>
                                                                    <label class="inputText openselect2">Employee Type</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-4 col-md-8 col-sm-12">
                                                            <div class="form-group">
                                                                <div class="form-group bmd-form-group">
                                                                    <input type="text" class="input form-control">
                                                                    <label class="inputText">Work Phone</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-3 col-md-4 col-sm-12">
                                                            <div class="form-group">
                                                                <div class="form-group bmd-form-group">
                                                                    <div class="input-group date">
                                                                        <input type="text" class="input form-control">
                                                                        <label class="inputText">Extension</label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                    <h4 data-toggle="collapse" href="#Personal" class="sub_hdng_edit"><i class="fa fa-chevron-down"></i> Personal Detaiils</h4>
                                    <div id="Personal" class="panel-collapse collapse show">
                                        <div class="m-t-30 m-b-15 col-12">
                                            <div class="row">
                                                <div class="col-md-6 colp_r_15">
                                                    <div class="row">
                                                        <div class="col-lg-4 col-md-5 col-sm-5">
                                                            <div class="form-group">
                                                                <div class="form-group bmd-form-group ">
                                                                    <input type="text" class="input form-control">
                                                                    <label class="inputText">Mobile Phone</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-8 col-md-7 col-sm-7">
                                                            <div class="form-group">
                                                                <div class="form-group bmd-form-group">
                                                                    <input type="text" class="input form-control">
                                                                    <label class="inputText">Other Email</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 colp_l_15">
                                                    <div class="row">
                                                        <div class="col-lg-8 col-md-8 col-sm-7">
                                                            <div class="form-group">
                                                                <div class="form-group bmd-form-group ">
                                                                    <input type="text" class="input form-control">
                                                                    <label class="inputText openselect2">Tags</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-4 col-md-4 col-sm-5">
                                                            <div class="form-group">
                                                                <div class="form-group bmd-form-group">
                                                                    <div class="input-group date">
                                                                        <input type="text" class="input form-control" id="dateofBirth">
                                                                        <span class="input-group-addon"> <i
                                                                                    class="fa fa-calendar"></i> </span>
                                                                        <label class="inputText">Date of Birth</label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6 colp_r_15">
                                                    <div class="row">
                                                        <div class="col-lg-4 col-md-5 col-sm-9">
                                                            <div class="form-group">
                                                                <div class="form-group bmd-form-group ">
                                                                    <select class="form-control">
                                                                        <option>Single</option>
                                                                        <option>Single</option>
                                                                        <option>Single</option>
                                                                    </select>
                                                                    <label class="inputText">Marital Status</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2 col-md-3 col-sm-3">
                                                            <div class="form-group">
                                                                <div class="form-group bmd-form-group">
                                                                    <input type="text" class="input form-control">
                                                                    <label class="inputText">Age</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 colp_l_15">
                                                    <div class="form-group">
                                                        <div class="form-group bmd-form-group ">
                                                            <textarea class="input_textaerea form-control" rows="1"></textarea>
                                                            <label class="inputText openselect2">Address</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                    <h4 data-toggle="collapse" href="#Summery" class="sub_hdng_edit"><i class="fa fa-chevron-down"></i> Summery</h4>
                                    <div id="Summery" class="panel-collapse collapse show">
                                        <div class="m-t-30 m-b-15 col-12">

                                            <div class="row">
                                                <div class="col-md-6 colp_r_15">
                                                    <div class="form-group">
                                                        <div class="form-group bmd-form-group ">
                                                            <textarea class="input_textaerea form-control" rows="1"></textarea>
                                                            <label class="inputText openselect2">Job Description</label>
                                                        </div>
                                                    </div>

                                                </div>
                                                <div class="col-md-6 colp_l_15">
                                                    <div class="form-group">
                                                        <div class="form-group bmd-form-group ">
                                                            <textarea class="input_textaerea form-control" rows="1"></textarea>
                                                            <label class="inputText openselect2">About Me</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6 colp_r_15">
                                                    <div class="form-group">
                                                        <div class="form-group bmd-form-group ">
                                                            <textarea class="input_textaerea form-control" rows="1"></textarea>
                                                            <label class="inputText openselect2">Ask Me About/Expertise</label>
                                                        </div>
                                                    </div>

                                                </div>
                                                <div class="col-md-6 colp_l_15">
                                                    <div class="row">
                                                        <div class="col-lg-4 col-md-5 col-sm-5">
                                                            <div class="form-group">
                                                                <div class="form-group bmd-form-group">
                                                                    <div class="input-group date">
                                                                        <input type="text" class="input form-control" id="dateofExit">
                                                                        <span class="input-group-addon"> <i
                                                                                    class="fa fa-calendar"></i> </span>
                                                                        <label class="inputText">Date of Exit</label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-4 col-md-5 col-sm-5">
                                                            <div class="form-group">
                                                                <div class="form-group bmd-form-group">
                                                                    <input type="text" class="input form-control">
                                                                    <label class="inputText">Gender</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>



                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-info pull-left">Save</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end row -->
            </div>
            <!-- container -->
        </div>
    </div>
</div>
<?php include("footer.php"); ?>
<script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.bootstrap4.min.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#datatable').DataTable();
        $('#responsive-datatable').DataTable();

        $('#datetimepicker1').datetimepicker({
            format: 'YYYY-MM-DD'
        });
        $('#datetimepicker2').datetimepicker({
            format: 'YYYY-MM-DD'
        });
        $('#joiningDate').datetimepicker({
            format: 'YYYY-MM-DD'
        });
        $('#dateofBirth').datetimepicker({
            format: 'YYYY-MM-DD'
        });
        $('#dateofExit').datetimepicker({
            format: 'YYYY-MM-DD'
        });
    });
</script>
</body>
</html>
