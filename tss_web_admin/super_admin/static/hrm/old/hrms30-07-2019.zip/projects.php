<?php include('header.php') ?>
<link href="css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css"/>
</head>
<body class="">
<div id="wrapper">
    <div class="left side-menu">
        <div class="slimscroll-menu" id="remove-scroll">
            <?php include('sidebar.php') ?>
            <div class="clearfix"></div>
        </div>
    </div>
    <div class="content-page ">
        <?php include('topnav.php') ?>
        <div class="content ">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="box_headerApprsal">
                            <div class="row">
                                <div class="col-md-4 col-12">
                                    <h4 class="m-t-0 header-title row">
                                        <div class="col p-l-3 p-r-3 clname">
                                            <select class="slect">
                                                <option>Jobs</option>
                                                <option>Jobs</option>
                                                <option>Jobs</option>
                                                <option>Jobs</option>
                                            </select>
                                        </div>
                                    </h4>
                                </div>
                                <div class="col-md-8 col-12">
                                    <div class="Apprsl_Filtr_Box">
                                        <form>
                                            <ul>
                                                <li class="dropdown FilterDrop">
                                                    <div class="dropdown-toggle" data-toggle="dropdown"><i
                                                                class="fa fa-filter"></i></div>
                                                </li>
                                                <div class="FilterDropBox hide">
                                                    <h4 class="float-left FilterDropTitle">Filter</h4>
                                                    <div class="float-right FilterCloseButton"><i
                                                                class="mdi mdi-close"></i>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                    <div class="col-md-12">
                                                        <div class="row">
                                                            <div class="col-lg-12">
                                                                <div class="form-group bmd_Filter">
                                                                    <label class="">Period</label>
                                                                    <select class="slect select2">
                                                                        <option>Administration</option>
                                                                        <option>Engineering</option>
                                                                        <option>Finance</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-12">
                                                                <div class="form-group bmd_Filter">
                                                                    <label class="">Projects</label>
                                                                    <select class="slect select2">
                                                                        <option>Administration</option>
                                                                        <option>Engineering</option>
                                                                        <option>Finance</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-12">
                                                                <div class="form-group bmd_Filter">
                                                                    <label class="">Jobs</label>
                                                                    <select class="slect select2">
                                                                        <option>Administration</option>
                                                                        <option>Engineering</option>
                                                                        <option>Finance</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-12">
                                                                <div class="form-group bmd_Filter">
                                                                    <label class="">Billable Status</label>
                                                                    <select class="slect select2">
                                                                        <option>Administration</option>
                                                                        <option>Engineering</option>
                                                                        <option>Finance</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-12">
                                                                <div class="form-group bmd_Filter">
                                                                    <label class="">Approval Status</label>
                                                                    <select class="slect select2">
                                                                        <option>Administration</option>
                                                                        <option>Engineering</option>
                                                                        <option>Finance</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <!--                                                            <div class="col-lg-12">
                                                                                                                            <label class=""><b>Experience</b></label>
                                                                                                                            <div class="row">
                                                                                                                                <div class="col-6">
                                                                                                                                    <div class="form-group bmd_Filter">
                                                                                                                                        <label class="">From</label>
                                                                                                                                        <div class="form-group">
                                                                                                                                            <div class='input-group date'>
                                                                                                                                                <input type='text'
                                                                                                                                                       class="form-control"
                                                                                                                                                       id='datetimepicker6'
                                                                                                                                                       autocomplete="off"/>
                                                                                                                                                <span class="input-group-addon">
                                                                                                                              <span class="fa fa-calendar"></span>
                                                                                                                              </span>
                                                                                                                                            </div>
                                                                                                                                        </div>
                                                                                                                                    </div>
                                                                                                                                </div>
                                                                                                                                <div class="col-6">
                                                                                                                                    <div class="form-group bmd_Filter">
                                                                                                                                        <label class="">To</label>
                                                                                                                                        <div class="form-group">
                                                                                                                                            <div class='input-group date'>
                                                                                                                                                <input type='text'
                                                                                                                                                       class="form-control"
                                                                                                                                                       id='datetimepicker7'
                                                                                                                                                       autocomplete="off"/>
                                                                                                                                                <span class="input-group-addon">
                                                                                                                              <span class="fa fa-calendar"></span>
                                                                                                                              </span>
                                                                                                                                            </div>
                                                                                                                                        </div>
                                                                                                                                    </div>
                                                                                                                                </div>
                                                                                                                            </div>
                                                                                                                        </div>
                                                            -->
                                                            <div class="col-lg-12 m-t-10">
                                                                <button class="btn btn-Searchh">Search</button>
                                                                <a class="linkColor">Reset</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- **************************************-->
                                                <li class="dropdown ExportDrop">
                                                    <a class="dropdown-toggle" data-toggle="dropdown"><i
                                                                class="fa fa-ellipsis-h"></i></a>
                                                    <div class="dropdown-menu">
                                                        <a class="dropdown-item" href="#">Export</a>
                                                        <a class="dropdown-item" href="#">Link 2</a>
                                                        <a class="dropdown-item" href="#">Link 3</a>
                                                    </div>
                                                </li>
                                            </ul>
                                        </form>
                                    </div>
                                    <a data-toggle="modal" class="btn btn-info newbtn_crete m-t-8 pull-right"
                                       data-target="#newLog">
                                        <i class="mdi mdi-plus-circle-outline"></i> Add Project
                                    </a>
                                    <a data-toggle="modal" class="PrInsideBtn"
                                       data-target="#newLog"> Department
                                    </a>
                                    <a data-toggle="modal" class="PrInsideBtn"
                                       data-target="#newLog"> User
                                    </a>
                                </div>
                            </div>
                        </div>
                        <!-- **************************************-->
                        <div class="card-box Card_height">
                            <div class="" id="tableview">
                                <div class="row">

                                    <table id="datatable" class="table table-bordered dt-responsive  table-hover tableprject"
                                           style="width: 100%;">

                                        <thead>
                                        <tr>
                                            <th>
                                                <div class="bulkCheckBox ProjectCheckBox">
                                                    <div class=" checkbox checkbox-info">
                                                        <input id="checkbox3" type="checkbox">
                                                        <label for="checkbox3"></label>
                                                    </div>
                                                </div>
                                            </th>
                                            <th>Project Name</th>
                                            <th>Estimated Hours</th>
                                            <th>Logged Hours</th>
                                            <th>Status</th>
                                            <th>Jobs</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>


                                        <tr>
                                            <td>
                                                <div class="bulkCheckBox ProjectCheckBox">
                                                    <div class=" checkbox checkbox-info">
                                                        <input id="checkbox3" type="checkbox">
                                                        <label for="checkbox3"></label>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="">
                                                    <span class="cl-badge-same-entries" data-toggle="collapse"
                                                          data-target="#Prjct1">3</span>
                                                    <span class="project_JobName"> Service Page - </span>
                                                    <span class="project_ProjectName"> RGS Website Development </span>
                                                </div>
                                            </td>
                                            <td>0 Hours 0 Min.</td>
                                            <td>5 Hours 23 Min.</td>
                                            <td>
                                                <div class="statusYes"></div>
                                            </td>
                                            <td>
                                                <div class="jobiconbox">
                                                    <i class="fa fa-file-text"></i><span class="JobCount">2</span>
                                                </div>
                                                <div class="jobaddbox hide">
                                                    <span><a class="AddJobButton"><i class="mdi mdi-plus"></i> Add Jobs </a></span>
                                                    <span class="jobaddboxClose"><i class="mdi mdi-close"></i></span>
                                                </div>
                                            </td>
                                            <td>
                                              <span class="dropdown projectEditDrop">
                                                  <span class="p-l-5 p-r-5 dropdown-toggle" data-toggle="dropdown">
                                                 <img src="images/menu-dots-vertical.svg">
                                                  </span>
                                                 <ul class="dropdown-menu">
                                                    <li><a href="#">Duplicate </a> </li>
                                                    <li><a href="#">Edit</a></li>
                                                    <li><a href="#">Delete</a></li>
                                                 </ul>
                                                </span>
                                            </td>
                                        </tr>

                                        <tr class="collapse" id="Prjct1">

                                            <td>
                                                <div class="bulkCheckBox ProjectCheckBox">
                                                    <div class=" checkbox checkbox-info">
                                                        <input id="checkbox3" type="checkbox">
                                                        <label for="checkbox3"></label>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="">
                                                    <span class="checkboxDummySpace"></span>
                                                    <span class="project_JobName"> Service Page - </span>
                                                    <span class="project_ProjectName"> RGS Website Development </span>
                                                </div>
                                            </td>
                                            <td>0 Hours 0 Min.</td>
                                            <td>5 Hours 23 Min.</td>
                                            <td>
                                                <div class="statusYes"></div>
                                            </td>
                                            <td>
                                                <div class="jobiconbox">
                                                    <i class="fa fa-file-text"></i><span
                                                            class="JobCount">2</span>
                                                </div>
                                                <div class="jobaddbox hide">
                                                    <span><a class="AddJobButton"><i class="mdi mdi-plus"></i> Add Jobs </a></span><span
                                                            class="jobaddboxClose"><i
                                                                class="mdi mdi-close"></i></span>
                                                </div>
                                            </td>
                                            <td>
                                              <span class="dropdown projectEditDrop">
                                             <span class="p-l-5 p-r-5 dropdown-toggle" data-toggle="dropdown"> <img
                                                         src="images/menu-dots-vertical.svg"> </span>
                                             <ul class="dropdown-menu">
                                                <li><a href="#">Duplicate </a> </li>
                                                <li><a href="#">Edit</a></li>
                                                <li><a href="#">Delete</a></li>
                                             </ul>
                                          </span>
                                            </td>

                                        </tr>
                                        <tr class="collapse" id="Prjct1">

                                            <td>
                                                <div class="bulkCheckBox ProjectCheckBox">
                                                    <div class=" checkbox checkbox-info">
                                                        <input id="checkbox3" type="checkbox">
                                                        <label for="checkbox3"></label>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="">
                                                    <span class="checkboxDummySpace"></span>
                                                    <span class="project_JobName"> Service Page - </span>
                                                    <span class="project_ProjectName"> RGS Website Development </span>
                                                </div>
                                            </td>
                                            <td>0 Hours 0 Min.</td>
                                            <td>5 Hours 23 Min.</td>
                                            <td>
                                                <div class="statusYes"></div>
                                            </td>
                                            <td>
                                                <div class="jobiconbox">
                                                    <i class="fa fa-file-text"></i><span
                                                            class="JobCount">2</span>
                                                </div>
                                                <div class="jobaddbox hide">
                                                    <span><a class="AddJobButton"><i class="mdi mdi-plus"></i> Add Jobs </a></span><span
                                                            class="jobaddboxClose"><i
                                                                class="mdi mdi-close"></i></span>
                                                </div>
                                            </td>
                                            <td>
                                              <span class="dropdown projectEditDrop">
                                             <span class="p-l-5 p-r-5 dropdown-toggle" data-toggle="dropdown"> <img
                                                         src="images/menu-dots-vertical.svg"> </span>
                                             <ul class="dropdown-menu">
                                                <li><a href="#">Duplicate </a> </li>
                                                <li><a href="#">Edit</a></li>
                                                <li><a href="#">Delete</a></li>
                                             </ul>
                                          </span>
                                            </td>

                                        </tr>

                                        </tbody>
                                    </table>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
            </div>
            <!-- end row -->
        </div>
        <!-- container -->
    </div>
</div>
</div>


<div id="AddNew_Project" class="modal fade modalpaddproject" role="dialog" data-backdrop="static">
    <div class="modal-dialog modal_sm">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">×</button>
                <h4 class="modal-title">Create Project</h4>
                <div class="pull-right">
                    <a class="btn dslarge_modal" data-toggle="tooltip" data-original-title="Back"><i
                                class="mdi mdi-arrow-expand-all" aria-hidden="true"></i> </a>
                </div>
            </div>
            <div class="modal-body">
                <form>
                    <div class="form_enterbox p-t-15">
                        <div class="row">
                            <div class="col-md-1">
                                <div class="form-group bmd-form-group">
                                    <input class="colorpicker" type="color" value="#000" oninput="color()">
                                </div>
                            </div>
                            <div class="col-md-11">
                                <div class="form-group">
                                    <div class="form-group bmd-form-group">
                                        <input type="text" class="input_textaerea form-control">
                                        <label class="inputText">Project Name</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-info" data-dismiss="modal">Save</button>
            </div>
        </div>
    </div>
</div>
<div id="newLog" class="modal fade modalpaddproject" role="dialog" data-backdrop="static">
    <div class="modal-dialog modal_md">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">×</button>
                <h4 class="modal-title">Create Project</h4>
                <div class="pull-right">
                    <a class="btn dslarge_modal" data-toggle="tooltip" data-original-title="Back"><i
                                class="mdi mdi-arrow-expand-all" aria-hidden="true"></i> </a>
                </div>
            </div>
            <div class="modal-body">
                <form>
                    <div class="col-md-12">
                        <div class="row m-t-15">
                            <div class="col-sm-6 pad5 ">
                                <div class="form-group bmd-form-group">
                                    <input type="text" class="input form-control">
                                    <label class="inputText">Project Name</label>
                                </div>
                            </div>
                            <div class="col-sm-6 pad5">
                                <div class="form-group bmd-form-group">
                                    <select class="form-control slect project">
                                        <option></option>
                                        <option>RGS</option>
                                        <option>RGS</option>
                                        <option>RGS</option>
                                    </select>
                                    <label class="inputText">Client</label>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 pad5 ">
                                <div class="form-group bmd-form-group">
                                    <input type="text" class="input form-control">
                                    <label class="inputText">Project Cost</label>
                                </div>
                            </div>
                            <div class="col-sm-6 pad5">
                                <div class="form-group bmd-form-group">
                                    <select class="form-control slect">
                                        <option>RGS</option>
                                        <option>RGS</option>
                                        <option>RGS</option>
                                    </select>
                                    <label class="inputText">Project Manager</label>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 pad5 ">
                                <div class="form-group bmd-form-group">
                                    <select class="form-control slect" multiple="multiple">
                                        <option value="AL">Alabama</option>
                                        <option value="WY">Wyoming</option>
                                    </select>
                                    <label class="inputText">Project Users</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-info" data-dismiss="modal">Save</button>
            </div>
        </div>
    </div>
</div>
<div id="AddNew_Job" class="modal fade modalpaddproject" role="dialog" data-backdrop="static">
    <div class="modal-dialog modal_sm">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">×</button>
                <h4 class="modal-title">Create New Clent</h4>
                <div class="pull-right">
                    <a class="btn dslarge_modal" data-toggle="tooltip" data-original-title="Back"><i
                                class="mdi mdi-arrow-expand-all" aria-hidden="true"></i> </a>
                </div>
            </div>
            <div class="modal-body">
                <form>
                    <div class="form_enterbox p-t-15">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <div class="form-group bmd-form-group">
                                            <input type="text" class="input_textaerea form-control">
                                            <label class="inputText">Client Name</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-info" data-dismiss="modal">Save</button>
            </div>
        </div>
    </div>
</div>
<?php include("footer.php"); ?>
<script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.bootstrap4.min.js"></script>
<script type="text/javascript">
    $(document).ready(function () {
        // Default Datatable
        $('#datatable').DataTable();
        $('#responsive-datatable').DataTable();
    });
</script>
<script>

    $(document).ready(function () {
        $('.jobiconbox').click(function () {
            $(this).addClass('hide');
            $(this).siblings().removeClass('hide');
        });
        $('.jobaddboxClose').click(function () {
            $(this).parent().addClass('hide');
            $('.jobiconbox').removeClass('hide');
        });

        $(".project").select2({
            placeholder: "Select",
        });
        $(".project").on("select2:open", function () {
            var a = $(this).data("select2");
            if (!$(".select2-link").length) {
                a.$results.parents(".select2-results")
                    .append('<div class="select2-link"><a data-toggle="modal" data-target="#AddNew_Job"> <img src="images/plus-blue-small.svg"> Create New Project </a></div>')
                    .on("click", function (b) {
                        a.trigger("close");
                    });
            }
        });

    });

</script>

</body>
</html>
