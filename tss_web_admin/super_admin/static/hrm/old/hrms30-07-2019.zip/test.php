<?php include('header.php') ?>

</head>

<body class="">
<div id="wrapper">
    <div class="left side-menu">
        <div class="slimscroll-menu" id="remove-scroll">
            <?php include('sidebar.php') ?>
            <div class="clearfix"></div>
        </div>
    </div>
    <div class="content-page ">
        <?php include('topnav.php') ?>
        <div class="content">
            <div class="container-fluid">
                <div id="" class="" role="dialog" data-backdrop="static">
                    <div class="modal-dialog modal_lg">
                        <div class="modal-content">
                            <div class="" id="tableview">

                                <div class="form_enterbox p-t-8">
                                    <div class="row">
                                        <div class="col-md-6 colp_r_15">

                                                    <label class="inputText">First Name</label>

                                        </div>
                                        <div class="col-md-6 colp_l_15">
                                            <div class="row">
                                                <div class="col-lg-9 col-md-8 col-sm-8">
                                                    <div class="form-group">
                                                        <div class="form-group bmd-form-group">
                                                            <select class="slect select2" id="jobtitle" name="jobtitle" disabled="true">
                                                                <option></option>

                                                            </select>
                                                            <label class="inputText">Job Title</label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-md-4 col-sm-4">
                                                    <div class="form-group">
                                                        <div class="form-group bmd-form-group">
                                                            <select class="slect select2" id="pay_grade" name="pay_grade" >
                                                                <option></option>

                                                            </select>
                                                            <label class="inputText openselect2">Pay Grade</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6 colp_r_15">
                                            <div class="form-group">
                                                <div class="form-group bmd-form-group">
                                                    <input type="text" class="input form-control" id="first_name" value="" name="first_name" readonly="">
                                                    <label class="inputText">Manager's Name</label>



                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6 colp_l_15">
                                            <div class="row">
                                                <div class="col-lg-4 col-md-6 col-sm-4">
                                                    <div class="form-group">

                                                        <input type="text" class="input form-control" id="first_name" value="" name="appraisal_date" readonly="">
                                                        <label class="inputText">Appraisal From</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 col-md-6 col-sm-4">
                                                    <div class="form-group">
                                                        <div class="form-group bmd-form-group">
                                                            <input type="text" class="input form-control" id="first_name" value="" name="appraisal_to" readonly="">
                                                            <span class="input-group-addon">
                                                                    <i class="fa fa-calendar"></i></span>
                                                            <label class="inputText">Appraisal To</label>


                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane active show" id="Objectives">
                                        <div class="row2 tbl_stngs commen_table">


                                            <div class="clearfix"></div>
                                            <div class="col-12">
                                                <div class="row">
                                                    <h4 class="modal_sub_hdng">Smart Performance Objectives</h4>
                                                </div>
                                            </div>
                                            <div class="clearfix"></div>
                                            <div class="tbl_addlist_crollbox">
                                                <table class="table table_bdr">
                                                    <thead>
                                                    <tr>
                                                        <th class="th_btnpand">
                                                            <div class="appnd_Smartperfmnc_btn append_btn">+</div>
                                                        </th>
                                                        <th class="th_object" >Smart Objective</th>
                                                        <th class="th_yerresult" >Year End Results/Accomplishments</th>
                                                        <th class="th_acheved" >Objective Achieved?</th>
                                                    </tr>
                                                    </thead>
                                                </table>
                                                <table class="table scrolbaletable">
                                                    <tbody class="apendsmart">
                                                    <tr>
                                                        <td class="th_btnpand">
                                                            <div class="appnd_Smartperfmnc_minus_btn appnd_minus_btn">-</div>
                                                        </td>
                                                        <td class="th_object">
                                                            <input type="text" class="input form-control" id="first_name" value="" name="appraisal_to" readonly="">
                                                        </td>
                                                        <td class="th_yerresult">
                                                            <input type="text" class="input form-control" id="first_name" value="" name="appraisal_to" readonly="">
                                                        </td>
                                                        <td class="th_acheved">
                                                            <input type="text" class="input form-control" id="first_name" value="" name="appraisal_to" readonly="">
                                                        </td>
                                                    </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                            <div class="clearfix"></div>
                                            <div class="col-12">
                                                <div class="row">
                                                    <h4 class="modal_sub_hdng">Managerial Competencies</h4>
                                                </div>
                                            </div>
                                            <div class="clearfix"></div>
                                            <div class="">
                                                <table class="table Competencies_table">
                                                    <thead>
                                                    <tr>
                                                        <th class="th_object">Competency</th>
                                                        <th class="th_yerresult">Observable Behaviors, Examples & Comments</th>
                                                        <th class="th_acheved">Rating</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody class="">

                                                    <tr>
                                                        <th style="" ></th>
                                                        <td class="">
                                                            <input type="text" class="input form-control" id="first_name" value="" name="appraisal_to" readonly="">
                                                        </td>
                                                        <td class="">
                                                            <input type="text" class="input form-control" id="first_name" value="" name="appraisal_to" readonly="">
                                                        </td>
                                                    </tr>




                                                    </tbody>
                                                </table>
                                            </div>
                                            <div class="clearfix"></div>
                                            <div class="col-12">
                                                <div class="row">
                                                    <h4 class="modal_sub_hdng">Job Specific Skills</h4>
                                                </div>
                                            </div>
                                            <div class="clearfix"></div>
                                            <div class="tbl_addlist_crollbox">
                                                <table class="table table_delpmnt_plan">
                                                    <thead>
                                                    <tr>
                                                        <th class="th_btnpand">
                                                            <div class="appnd_managerial_btn append_btn">+</div>
                                                        </th>
                                                        <th class="th_jobskill">Job Specific Skill</th>
                                                        <th class="th_behavir">Observable Behaviors, Examples & Comments</th>
                                                        <th class="th_acheved">Rating</th>
                                                    </tr>
                                                    </thead>
                                                </table>
                                                <table class="table scrolbaletable">
                                                    <tbody class="apendmanagerial">
                                                    <tr>
                                                        <td class="th_btnpand">
                                                            <div class="appnd_managerial_minus_btn appnd_minus_btn">-</div>
                                                        </td>
                                                        <td class="th_jobskill">
                                                            <input type="text" class="input form-control" id="first_name" value="" name="appraisal_to" readonly="">
                                                        </td>
                                                        <td class="th_behavir">
                                                            <input type="text" class="input form-control" id="first_name" value="" name="appraisal_to" readonly="">
                                                        </td>
                                                        <td class="th_acheved">
                                                            <input type="text" class="input form-control" id="first_name" value="" name="appraisal_to" readonly="">
                                                        </td>
                                                    </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                            <div class="clearfix"></div>
                                            <div class="col-12">
                                                <div class="row">
                                                    <h4 class="modal_sub_hdng">Appraisal Summary Performance</h4>
                                                </div>
                                            </div>
                                            <div class="clearfix"></div>
                                            <table class="table Competencies_table">
                                                <tbody>
                                                <tr>
                                                    <th>Performance Competencies</th>
                                                    <td>
                                                        <input type="text" class="input form-control" id="first_name" value="" name="appraisal_to" readonly="">
                                                    </td>
                                                    <th>Competencies</th>
                                                    <td>
                                                        <input type="text" class="input form-control" id="first_name" value="" name="appraisal_to" readonly="">
                                                    </td>
                                                    <th>Overall Rating</th>
                                                    <td>
                                                        <input type="text" class="input form-control" id="first_name" value="" name="appraisal_to" readonly="">
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>



                                        </div>
                                    </div>

                                    <div class="tab-pane" id="Development-Plan">
                                        <div class="row2 tbl_stngs commen_table">


                                            <div class="clearfix"></div>
                                            <div class="col-12">
                                                <div class="row">
                                                    <h4 class="modal_sub_hdng">Performance Overview</h4>
                                                </div>
                                            </div>
                                            <div class="clearfix"></div>
                                            <div class="coment_section">
                                                <table class="table Competencies_table">
                                                    <thead>
                                                    <tr>
                                                        <th class="th_object">Strengths</th>
                                                        <th class="th_yerresult">Development Needs</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody class="">
                                                    <tr>
                                                        <td style="width: 50%">

                                                        </td>
                                                        <td class="">

                                                            <input type="text" class="input form-control" id="first_name" value="" name="appraisal_to" readonly="">
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="">
                                                            <input type="text" class="input form-control" id="first_name" value="" name="appraisal_to" readonly="">
                                                        </td>
                                                        <td class="">
                                                            <input type="text" class="input form-control" id="first_name" value="" name="appraisal_to" readonly="">
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="">
                                                            <input type="text" class="input form-control" id="first_name" value="" name="appraisal_to" readonly="">
                                                        </td>
                                                        <td class="">
                                                            <input type="text" class="input form-control" id="first_name" value="" name="appraisal_to" readonly="">
                                                        </td>
                                                    </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                            <div class="clearfix"></div>
                                            <div class="col-12">
                                                <div class="row">
                                                    <h4 class="modal_sub_hdng">Development Plan</h4>
                                                </div>
                                            </div>
                                            <div class="clearfix"></div>
                                            <div class="tbl_addlist_crollbox">
                                                <table class="table table_delpmnt_planmain">
                                                    <thead>
                                                    <tr>
                                                        <th class="th_btnpand">
                                                            <div class="appnd_dvlp_plan_btn append_btn append_btn-dvlpmt">+</div>
                                                        </th>
                                                        <th class="th_devlp_Competency">Competency
                                                            <br>(Skill, Capability or Behavior)</th>
                                                        <th class="th_devlp_Objectives">Development Objectives</th>
                                                        <th class="th_devlp_Activity">Development Activity</th>
                                                        <th class="th_devlp_Resources">Support Required
                                                            <br>(people, tools, resources)</th>
                                                        <th class="th_devlp_When">By When?</th>
                                                        <th class="th_devlp_Measurement">Measurement Process</th>
                                                    </tr>
                                                    </thead>
                                                </table>
                                                <table class="table scrolbaletable_delpmnt_plan2 ">
                                                    <tbody class="apenddvlp">
                                                    <tr>
                                                        <td class="th_btnpand">
                                                            <div class="appnd_dvlp_plan_minus_btn appnd_minus_btn">-</div>
                                                        </td>
                                                        <td class="th_devlp_Competency">
                                                            <input type="text" class="input form-control" id="first_name" value="" name="appraisal_to" readonly="">
                                                        </td>
                                                        <td class="th_devlp_Objectives">
                                                            <input type="text" class="input form-control" id="first_name" value="" name="appraisal_to" readonly="">
                                                        </td>
                                                        <td class="th_devlp_Activity" >
                                                            <input type="text" class="input form-control" id="first_name" value="" name="appraisal_to" readonly="">
                                                        </td>
                                                        <td class="th_devlp_Measurement">
                                                            <input type="text" class="input form-control" id="first_name" value="" name="appraisal_to" readonly="">
                                                        </td>
                                                        <td class="th_devlp_When position_inherit">
                                                            <div class='input-group date position_inherit'>
                                                                <input type="text" class="input form-control" id="first_name" value="" name="appraisal_to" readonly="">
                                                            </div>
                                                        </td>
                                                        <td class="th_devlp_Measurement">
                                                            <input class="form-control" />
                                                        </td>
                                                    </tr>
                                                    </tbody>
                                                </table>
                                            </div>


                                        </div>
                                    </div>
                                    <div class="tab-pane" id="Appraisal-Summary">
                                        <div class="row2 tbl_stngs commen_table">


                                            <div class="clearfix"></div>
                                            <div class="col-12">
                                                <div class="row">
                                                    <h4 class="modal_sub_hdng">RGS Comment Section</h4>
                                                </div>
                                            </div>
                                            <div class="clearfix"></div>
                                            <div class="coment_section">
                                                <table class="table Competencies_table">
                                                    <thead>
                                                    <tr>
                                                        <th class="th_object">Employee (Comment limited to 1100 characters )</th>
                                                        <th class="th_yerresult">Manager (Comment limited to 1100 characters)</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody class="">
                                                    <tr>
                                                        <td style="width: 50%">
                                                            <textarea class="form-control" name="employee_comment" id="employee_comment"></textarea>
                                                        </td>
                                                        <td>
                                                            <textarea class="form-control" name="manager_comment" id="manager_comment"></textarea>
                                                        </td>
                                                    </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                            <div class="clearfix"></div>
                                            <div class="col-12">
                                                <div class="row">
                                                    <h4 class="modal_sub_hdng">Code of Conduct</h4>
                                                </div>
                                            </div>
                                            <div class="clearfix"></div>
                                            <div class="code_conduct">
                                                <p>Is the employee aware of any events or situations which might constitute a violation of the RGS Code of Conduct? If yes, the manager must take action in accordance with the RGS Code of Conduct</p>
                                                <div class="code_conduct_select">
                                                    <select class="form-control" name="conduct_status" id="conduct_status">
                                                        <option>Yes</option>
                                                        <option>No</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="tab-pane" id="Mid-year">
                                                <div class="row2 tbl_stngs commen_table">

                                                    <div class="clearfix"></div>
                                                    <div class="midyr_insrctn">
                                                        <h5>Mid-year Review Instructions</h5>
                                                        <p>Is the employee aware of any events or situations which might constitute a violation of the RGS Code of Conduct? If yes, the manager must take action in accordance with the RGS Code of Conduct</p>
                                                    </div>
                                                    <div class="m-t-10">
                                                        <div class="col-12">
                                                            <div class="row">
                                                                <h4 class="modal_sub_hdng">Smart Objectives</h4>
                                                            </div>
                                                        </div>
                                                        <textarea class="form-control" name="smart_objectives" id="smart_objectives"></textarea>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                    <div class="m-t-10">
                                                        <div class="col-12">
                                                            <div class="row">
                                                                <h4 class="modal_sub_hdng">RGS Managerial Competencies</h4>
                                                            </div>
                                                        </div>
                                                        <textarea class="form-control" name="managerical_competencies" id="managerical_competencies"></textarea>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                    <div class="m-t-10">
                                                        <div class="col-12">
                                                            <div class="row">
                                                                <h4 class="modal_sub_hdng">Job Specific Skills</h4>
                                                            </div>
                                                        </div>
                                                        <textarea class="form-control" name="specific_skill" id="specific_skill"></textarea>
                                                    </div>
                                                    <div class="clearfix"></div>


                                                </div>
                                            </div>


                                        </div>

                                    </div>
                                </div>
                            </div>

                            </form>





                        </div>
                    </div>
                </div>
                <!-- end row -->
            </div>
            <!-- container -->
        </div>
    </div>
</div>


<?php include("footer.php"); ?>


</body>

</html>
