<footer class="footer">
    <ul class="footaernav">
        <a href="settings.php">
            <li class=""><i class="fa fa-cog" data-toggle="tooltip" title="" data-original-title="Settings"></i></li>
        </a>
        <a id="add_new" class="add_new">
            <li class="" data-toggle="tooltip" title="" data-original-title="Sticky Notes"><i class="fa fa-sticky-note"></i></li>
        </a>
        <a href="">
            <li class=""><i class="fa fa-plus" data-toggle="tooltip" title="" data-original-title="Add"></i></li>
        </a>
    </ul>
</footer>


<div class="add-note">
    <input name="title" id="title" maxlength="50" placeholder="Title"/>
    <textarea name="text" id="text" cols="25" rows="5" placeholder="Text"></textarea>
    <button class="btn btn-info">Add</button>
</div>

<div class="wrap">
</div>

<script id="entry-template" type="text/x-handlebars-template">
    <div class="mainbar">
        <span>{{title}}</span>
        <div class="closesticky"><i class="fa fa-times-circle fa-fw"></i></div>
        <div class="minimize"><i class="fa fa-minus-square-o fa-fw"></i></div>
    </div>
    <pre class="text">{{text}}</pre>
</script>

<!-- <script src="js/modernizr.min.js"></script> -->
<script src="js/jquery.min.js"></script>
<script src='js/handlebars.min.js'></script>
<script src="js/sticky.js"></script>

<script src="js/main.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/metisMenu.min.js"></script>
<script src="js/waves.js"></script>
<script src="js/jquery.slimscroll.js"></script>



<script src="js/morris.min.js"></script>
<script src="js/raphael-min.js"></script>
<script src="js/jquery.morris.init.js"></script>

<script src="js/bootstrap-filestyle.min.js" type="text/javascript"></script>
<script src="js/moment.js"></script>
<script src="js/bootstrap-timepicker.js"></script>
<script src="js/bootstrap-colorpicker.min.js"></script>
<script src="js/bootstrap-datepicker.min.js"></script>
<script src="js/jquery.form-pickers.init.js"></script>
<script src="js/bs_settngsnavi.js"></script>
<script src="js/kanban.js"></script>
<!--[if IE]>
<![endif]-->
<script>
    let eleBtnStart = document.querySelector("#btnStart");
    let eleBtnStop = document.querySelector("#btnStop");
    let eleTimer = document.querySelector("#divTimer");

    let timeTicker = (() => {
        var hours = minutes = seconds = 0;
        var timerTick;
        return {
            start : () => {
                if(!timerTick) {
                    timerTick = setInterval(() => {
                        seconds++;
                        if(seconds == 60) {
                            minutes += 1;
                            seconds = 0;
                            if(minutes == 60) {
                                hours += 1;
                                minutes = 0;
                            }
                        }
                        eleTimer.innerHTML = `
${hours.toString().length == 1 ? "0" + hours : hours}
: ${minutes.toString().length == 1 ? "0" + minutes:minutes} Hrs`;
                    },25);
                }
            },
            stop : () => {
                if(timerTick) {
                    clearInterval(timerTick);
                    timerTick = false;
                }
            },
            reset : () => {
                seconds = minutes = hours = 0;
                clearInterval(timerTick);
                timerTick = false;
                eleTimer.innerHTML = `0${hours}:0${minutes}  Hrs`;
            }
        }
    })();
 eleBtnStart.addEventListener('click', () => {
        timeTicker.start();
    });
    eleBtnStop.addEventListener('click', () => {
        timeTicker.stop();
    });

    $('#btnStart').click(function (){
        $(this).closest('.timer').addClass('timer_actv')
    });
    $('#btnStop').click(function (){
        $(this).closest('.timer').removeClass('timer_actv')
    });



</script>
<script>
   $(document).ready(function(){
       $('.timerbtn_start').click(function (){
           $(this).addClass('disnone_timer')
           $(this).siblings('.timerbtn').addClass('timerbtn_stop')
       });
       $('.timerbtn_stop').click(function (){
           $(this).removeClass('timerbtn_stop')
           $(this).siblings('.timerbtn').removeClass('disnone_timer')
       });


     $('#searchform').submit(function(e){
       e.preventDefault(); // stop form submission
     });
     $('.open-right').click(function(){
     $('.sidenav').toggleClass('sidenavshow');
     });
     $(".enlarge").click(function() {
           $(this).parent().parent().parent().parent().parent().addClass("largclss");
       });
   $(".dslarge").click(function() {
       $(this).parent().parent().parent().parent().parent().removeClass("largclss");
   });
     $(".enlarge_modal").click(function() {
           $(this).parent().parent().parent().parent().addClass("largclss");
       });
   $(".dslarge_modal").click(function() {
       $(this).parent().parent().parent().parent().removeClass("largclss");
   })
   });
</script>

<script>
    let ready = $(document).ready(function(){

        function checkForInput(element) {
              const $label = $(element).siblings('label.inputText');
            if ($(element).val().length > 0) {
                $label.addClass('input-has-value');
            } else {
                $label.removeClass('input-has-value');
            }}
        $('input.input').each(function() {
            checkForInput(this);
        });
        $('input.input').on('change keyup', function() {
            checkForInput(this);
        });

    function checkForTextarea(element) {
        const $label = $(element).siblings('label.inputText');
        if ($(element).val().length > 0) {
            $label.addClass('input-has-value');
        } else {
            $label.removeClass('input-has-value');
        }}
    $('textarea.input_textaerea').each(function() {
        checkForTextarea(this);
    });
    $('textarea.input_textaerea').on('change keyup', function() {
        checkForTextarea(this);
    });

        $('.input').each(function(){
            if($(this).hasClass('getVal')) {
                $(this).siblings('label.inputText').addClass('input-has-value');
            }
        });

       /* if ($('.input').hasClass('getVal')){
            $(this).siblings('label.inputText').addClass('input-has-value')
        };*/

        $('select').on('change', function () {
            var selectVal = $("select option:selected").val();
                $(this).siblings('label.inputText').addClass('input-has-value');
        });

        $( ".clearbtnn" ).click(function() {
            $('label.inputText').removeClass('input-has-value ');
        });

    });
</script>
<script>
    $(function() {
    $('#sidebar-menu > ul > li > a').click(function () {
        $(this).parent().addClass('sidebar_nav_actv');
        $(this).parent().siblings().removeClass('sidebar_nav_actv');
        $(this).siblings('.sidebar_sub_division').toggleClass('wdth');
        $(this).parent().siblings().find('.sidebar_sub_division').removeClass('wdth');
    });
    $('.bootm_toggle_button').click(function () {
        $(".sidebar_sub_division").removeClass('wdth');

    });
    $('.sidebar_sub_division a').click(function () {
        $("this").addClass('sidebar_nav_sub_actv');
        $(".sidebar_nav_actv").removeClass('sidebar_nav_actv');
    });
    $(document).on("click", function(e) {
        if ($(e.target).is(".sidebar_nav_actv") === false) {
            alert("asdsfgfb")
            $(".sidebar_nav_actv").siblings().removeClass('wdth');
        }
    });
       $(".sidebar_sub_division a").each(function() {
        window.location.href, $(this).prop("href") == window.location.href && ($(this).addClass("current"),
         $(this).parent().parent().addClass("menu-open"),
         $(this).closest('li.active').addClass("sidebar_nav_actv"))
         })
    });

</script>

<script src="js/jquery.core.js"></script>
<script src="js/jquery.app.js"></script>
<!-- App js -->
<script src="js/select2.full.js"></script>
<script src="js/select2-custome.js"></script>

