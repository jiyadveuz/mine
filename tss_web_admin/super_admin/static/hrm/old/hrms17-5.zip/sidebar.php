

<div class="topbar-left">
    <a href="index.php" class="logo">
          <!--     <span>
           <img src="images/logo-dark-text.png" alt="" >
               </span>-->
        <i>
            <img src="images/fav.png" alt="">
        </i>
    </a>
</div>

<!--- Sidemenu -->
<div id="sidebar-menu" class="sidaber_menu">

    <ul class="metismenu" id="side-menu">

        <!--<li class="menu-title">Navigation</li>-->

        <li>
            <a>
                <i class="fa fa-dashboard"></i> <p> Dashboard </p>
            </a>
            <div class="sidebar_sub_division">

                    <p> <a href="index.php"> Home </a> </p>
            </div>

        </li>
        <li>
            <a>
                <i class="fa fa-dashboard"></i> <p> Self-Service </p>
            </a>
            <div class="sidebar_sub_division">

                <p> <a href="employee-master.php"> Employee Master </a> </p>
                <p> <a href="profile.php"> Profile </a> </p>
            </div>
        </li>
        <li>
            <a href="employee-master.php">
                <i class="fa fa-user"></i> <p> Employee Master </p>
            </a>
        </li>

    </ul>


</div>
<!-- Sidebar -->
<div class="bootm_toggle_button">
 <i class="fa fa-align-right"></i>

</div>
