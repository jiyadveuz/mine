<?php include( 'header.php') ?>
<link href="css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
</head>

<body class="">
<!-- Begin page -->
<div id="wrapper">
    <!-- ========== Left Sidebar Start ========== -->
    <div class="left side-menu">
        <div class="slimscroll-menu" id="remove-scroll">
            <!-- LOGO -->
            <div class="topbar-left">
                <a href="index.php" class="logo"> <span>
            <img src="images/logo-dark-text.png" alt="">
            </span>
                    <i>
                        <img src="images/fav.png" alt="">
                    </i>
                </a>
            </div>
            <?php include( 'sidebar.php') ?>
            <div class="clearfix"></div>
        </div>
        <!-- Sidebar -left -->
    </div>
    <!-- Left Sidebar End -->
    <!-- ============================================================== -->
    <?php include( 'left-settings-menu.php') ?>
    <!-- ============================================================== -->
    <div class="content-page ">
        <?php include( 'topnav.php') ?>
        <!-- Start Page content -->
        <div class="content settings-cntnt-box">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="box_header">
                            <div class="row">
                                <div class="col-md-12 col-12">
                                    <div class="mainiconbox"><i class="fa fa-twitch"></i>
                                    </div>
                                    <h4 class="m-t-0 header-title">
                                        <div class="breadcrumbs ng-scope">
                                            <ul>
                                                <li><a href="index.php">Home</a></li>
                                                <li><a href="settings.php">Settings</a></li>
                                                <li><a href="#">Role</a></li>
                                            </ul>
                                            <div>Role</div>
                                        </div>
                                    </h4>
                                </div>
                            </div>
                        </div>
                        <div class="card-box ">
                            <div class="" >

                                    <form>
                                        <div class="col-md-12">
                                            <div class="row m-t-15">
                                                <div class="col-xl-7 col-lg-12 col-md-12 colp_r_15">
                                                    <div class="row">
                                                        <div class="col-md-7">
                                                        <div class="col-md-8">
                                                            <div class="form-group">
                                                                <div class="form-group bmd-form-group">
                                                                    <input type="text" class="input form-control">
                                                                    <label class="inputText openselect2">Role Name</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <textarea rows="1" class="form-control input_textaerea tstarea"></textarea>
                                                                <label class="bmd-label-floating inputText">Description</label>
                                                            </div>
                                                        </div>
                                                    </div>

                                                        <div class="col-md-5">
                                                            <div class="user_daterangpickrbox expirationbox m-t-10-imprtnt">

                                                                    <h3 class="big_title2">Effective Date</h3>

                                                                <div class="input-daterange p-t-15" id="date-range">
                                                                    <div class="row">
                                                                        <div class="col-md-6">
                                                                            <div class="input-group bmd-date-group">
                                                                                <input type="text" class="form-control input" name="starta" />
                                                                                <label class="bmd-label-floating inputText labl_insd">From</label>
                                                                                <div class="input-group-append"> <span class="input-group-text "><i class="mdi mdi-calendar"></i></span>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-6">
                                                                            <div class="input-group ">
                                                                                <input type="text" class="form-control input" name="enda" />
                                                                                <label class="bmd-label-floating inputText labl_insd">To</label>
                                                                                <div class="input-group-append"> <span class="input-group-text "><i class="mdi mdi-calendar"></i></span>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row m-t-15">
                                        <div class="col-xl-7 col-lg-12 col-md-12">
                                            <div class="row_addroltablealign">
                                                <table class="addroletablealn">
                                                    <thead>
                                                    <tr class="bgcolr1">
                                                        <th style=" border-bottom: 1px solid #e7e7e7;width: 160px"></th>
                                                        <th>Read</th>
                                                        <th>Write</th>
                                                        <th>Edit</th>
                                                        <th>Delete</th>
                                                        <th>View All</th>
                                                        <th>Manage All</th>

                                                    </tr>
                                                    </thead>
                                                    <tbody>

                                                    <tr>
                                                        <th>User</th>
                                                        <td>




                                                            <div class="checkbox">
                                                                <input id="CheckRead_9" name="roleLinkAllocation[0].readAccess" type="checkbox" value="1">
                                                                <input type="hidden" name="_roleLinkAllocation[0].readAccess" value="on">
                                                                <label for="CheckRead_9"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_2" checked="">
                                                                <label for="Checkbox_2"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_3">
                                                                <label for="Checkbox_3"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_4">
                                                                <label for="Checkbox_4"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_5" checked="">
                                                                <label for="Checkbox_5"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_11" checked="">
                                                                <label for="Checkbox_11"></label>
                                                            </div>
                                                        </td>

                                                    </tr>

                                                    <tr>
                                                        <th>Customer</th>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_6">
                                                                <label for="Checkbox_6"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_7">
                                                                <label for="Checkbox_7"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_8">
                                                                <label for="Checkbox_8"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_9">
                                                                <label for="Checkbox_9"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_10">
                                                                <label for="Checkbox_10"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_12">
                                                                <label for="Checkbox_12"></label>
                                                            </div>
                                                        </td>

                                                    </tr>

                                                    <tr>
                                                        <th>Employee</th>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_6" checked="">
                                                                <label for="Checkbox_6"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_7">
                                                                <label for="Checkbox_7"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_8" checked="">
                                                                <label for="Checkbox_8"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_9">
                                                                <label for="Checkbox_9"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_10">
                                                                <label for="Checkbox_10"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_10">
                                                                <label for="Checkbox_10"></label>
                                                            </div>
                                                        </td>

                                                    </tr>

                                                    <tr>
                                                        <th>Quatation</th>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_6">
                                                                <label for="Checkbox_6"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_7">
                                                                <label for="Checkbox_7"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_8">
                                                                <label for="Checkbox_8"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_9" checked="">
                                                                <label for="Checkbox_9"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_10">
                                                                <label for="Checkbox_10"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_10">
                                                                <label for="Checkbox_10"></label>
                                                            </div>
                                                        </td>

                                                    </tr>

                                                    <tr>
                                                        <th>Sales Order</th>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_6">
                                                                <label for="Checkbox_6"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_7">
                                                                <label for="Checkbox_7"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_8">
                                                                <label for="Checkbox_8"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_9">
                                                                <label for="Checkbox_9"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_10">
                                                                <label for="Checkbox_10"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_10">
                                                                <label for="Checkbox_10"></label>
                                                            </div>
                                                        </td>

                                                    </tr>

                                                    <tr>
                                                        <th>Estimate</th>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_6">
                                                                <label for="Checkbox_6"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_7">
                                                                <label for="Checkbox_7"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_8">
                                                                <label for="Checkbox_8"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_9">
                                                                <label for="Checkbox_9"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_10">
                                                                <label for="Checkbox_10"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_10">
                                                                <label for="Checkbox_10"></label>
                                                            </div>
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <th>Item Master</th>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_6">
                                                                <label for="Checkbox_6"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_7">
                                                                <label for="Checkbox_7"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_8">
                                                                <label for="Checkbox_8"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_9">
                                                                <label for="Checkbox_9"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_10">
                                                                <label for="Checkbox_10"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_10">
                                                                <label for="Checkbox_10"></label>
                                                            </div>
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <th style="height: 30px"></th>
                                                        <th>Add</th>
                                                        <th>View</th>
                                                        <th colspan="4"></th>
                                                    </tr>
                                                    <tr>
                                                        <th>Inventory</th>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_6">
                                                                <label for="Checkbox_6"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_7">
                                                                <label for="Checkbox_7"></label>
                                                            </div>
                                                        </td>
                                                        <td colspan="4"></td>

                                                    </tr>

                                                    <tr>
                                                        <th>Settings</th>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_6">
                                                                <label for="Checkbox_6"></label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="checkbox">
                                                                <input type="checkbox" id="Checkbox_7">
                                                                <label for="Checkbox_7"></label>
                                                            </div>
                                                        </td>
                                                        <td colspan="4"></td>

                                                    </tr>

                                                    </tbody>
                                                </table>

                                            </div>
                                        </div>

                                            </div>
                                        </div>
                                    </form>

                            </div>
                        </div>
                    </div>
                </div>
                <!-- end row -->
            </div>
            <!-- container -->
        </div>
    </div>
</div>

<?php include( "footer.php"); ?>
<script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.bootstrap4.min.js"></script>
<script type="text/javascript">
    $(document).ready(function () {

        // Default Datatable
        $('#datatable').DataTable();
        $('#responsive-datatable').DataTable();

        // Multi Selection Datatable
        $('#selection-datatable').DataTable({
            select: {
                style: 'multi'
            }
        });
        table.buttons().container()
            .appendTo('#datatable-buttons_wrapper .col-md-6:eq(0)');
    });
</script>
<script type="text/javascript">
    $(document).ready(function () {
        $("#passwd_day").click(function () {
            $(this).closest(".user_daterangpickrbox").find(".password_day_countbox").removeClass("hide");
        });
        $("#passwd_no_expire").click(function () {
            $(this).closest(".user_daterangpickrbox").find(".password_day_countbox").addClass("hide");
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $("#btn1").click(function() {
            $(".roleappend").append('<tr>'+
                '<td class="user_role_wdth">   <select class="slect select2">'+
                ' <option>Select A</option><option>Select B</option><option>Select C</option><option>Select D</option></select></td>' +
                '<td class="user_decptn_wdth"> <input type="text" class="form-control"></td>' +
                '<td><table><tr>' +
                '<td class="user_strtDate_wdth"><div class="row"><div class="col-12">' +
                '<div class="input-group"><input type="text" class="form-control input" name="start"/>' +
                '<div class="input-group-append"><span class="input-group-text"><i class="mdi mdi-calendar"></i></span>' +
                '</div></div></div></div></td>' +
                '<td class="user_endDate_wdth"><div class="row"><div class="col-12">' +
                '<div class="input-group"><input type="text" class="form-control input" name="start"/>' +
                '<div class="input-group-append"><span class="input-group-text"><i class="mdi mdi-calendar"></i></span>' +
                '</div> </div></div></div></td>' +
                '</tr></table><td>' +
                '<td>' +
                '</td></tr>');
            $(".slect").select2();

        });
    });
</script>

</body>

</html>
