<?php include('header.php') ?>
</head>
<body class="">
<!-- Begin page -->
<div id="wrapper">
    <!-- ========== Left Sidebar Start ========== -->
    <div class="left side-menu">
        <div class="slimscroll-menu" id="remove-scroll">
            <!-- LOGO -->

            <?php include('sidebar.php') ?>
            <div class="clearfix"></div>
        </div>
        <!-- Sidebar -left -->
    </div>
    <!-- Left Sidebar End -->
    <!-- ============================================================== -->
    <!-- Start right Content here -->
    <!-- ============================================================== -->
    <div class="content-page">
        <?php include('topnav.php') ?>
        <!-- Start Page content -->
        <div class="content">
            <div class="container-fluid">
                <!-- end row -->
                <div class="row">


                    <div class="card-box-dashbord">
                        <h4 class="header-title">Order Overview</h4>
                        <div class="card-box">

                            <div style="height: 350px;" class="mt-4"></div>
                    </div>
                    </div>

                    <div class="card-box-dashbord">
                        <h4 class="header-title">Order Overview</h4>
                        <div class="card-box">

                            <div class="mt-4"></div>
                        </div>
                    </div>

                    <div class="card-box-dashbord">
                        <h4 class="header-title">Order Overview</h4>
                        <div class="card-box">

                            <div class="mt-4"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- container -->
</div>
<!-- content -->
<?php include('footer.php') ?>
</body>
</html>
