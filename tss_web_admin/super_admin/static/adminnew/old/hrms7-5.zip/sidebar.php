
<!--- Sidemenu -->
<div id="sidebar-menu" class="sidaber_menu">

    <ul class="metismenu" id="side-menu">

        <!--<li class="menu-title">Navigation</li>-->

        <li>
            <a href="index.php">
                <i class="fa fa-dashboard"></i> <span> Dashboard </span>
            </a>
        </li>
        <li>
            <a href="employee-master.php">
                <i class="fa fa-user"></i> <span> Employee Master </span>
            </a>
        </li>












</div>
<!-- Sidebar -->
