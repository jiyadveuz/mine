<?php include('header.php') ?>
</head>
<body class="">
<!-- Begin page -->
<div id="wrapper">
<!-- ========== Left Sidebar Start ========== -->
<div class="left side-menu">
    <div class="slimscroll-menu" id="remove-scroll">
        <!-- LOGO -->
        <div class="topbar-left">
            <a href="index.php" class="logo">
               <span>
               <img src="images/logo-dark-text.png" alt="" >
               </span>
                <i>
                    <img src="images/fav.png" alt="">
                </i>
            </a>
        </div>
        <?php include('sidebar.php') ?>
        <div class="clearfix"></div>
    </div>
    <!-- Sidebar -left -->
</div>
<!-- Left Sidebar End -->
<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
    <?php include('topnav.php') ?>
    <!-- Start Page content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6 col-xl-3">
                    <div class="card-box widget-flat border-custom bg-custom text-white">
                        <i class="fi-tag"></i>
                        <h3 class="m-b-10">25563</h3>
                        <p class="text-uppercase m-b-5 font-13 font-600">Total tickets</p>
                    </div>
                </div>
                <div class="col-md-6 col-xl-3">
                    <div class="card-box bg-primary widget-flat border-primary text-white">
                        <i class="fi-archive"></i>
                        <h3 class="m-b-10">6952</h3>
                        <p class="text-uppercase m-b-5 font-13 font-600">Pending Tickets</p>
                    </div>
                </div>
                <div class="col-md-6 col-xl-3">
                    <div class="card-box widget-flat border-success bg-success text-white">
                        <i class="fi-help"></i>
                        <h3 class="m-b-10">18361</h3>
                        <p class="text-uppercase m-b-5 font-13 font-600">Closed Tickets</p>
                    </div>
                </div>
                <div class="col-md-6 col-xl-3">
                    <div class="card-box bg-danger widget-flat border-danger text-white">
                        <i class="fi-delete"></i>
                        <h3 class="m-b-10">250</h3>
                        <p class="text-uppercase m-b-5 font-13 font-600">Deleted Tickets</p>
                    </div>
                </div>
            </div>
            <!-- end row -->
            <div class="row">
                <div class="col-xl-6">
                    <div class="card-box">
                        <h4 class="header-title">Order Overview</h4>
                        <div id="morris-bar-stacked" style="height: 350px;" class="mt-4"></div>
                    </div>
                </div>
                <div class="col-xl-6">
                    <div class="card-box">
                        <h4 class="header-title">Sales Overview</h4>
                        <div id="morris-area-example" style="height: 350px;" class="mt-4"></div>
                    </div>
                </div>
            </div>
            <!-- end row -->
            <div class="row">
                <div class="col-xl-8">
                    <div class="card-box">
                        <h4 class="header-title mb-3">Wallet Balances</h4>
                        <div class="table-responsive">
                            <table class="table table-hover table-centered m-0">
                                <thead>
                                <tr>
                                    <th>Profile</th>
                                    <th>Name</th>
                                    <th>Currency</th>
                                    <th>Balance</th>
                                    <th>Reserved in orders</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>
                                        <img src="images/7.jpg" alt="contact-img" title="contact-img" class="rounded-circle thumb-sm" />
                                    </td>
                                    <td>
                                        <h5 class="m-0 font-weight-normal">Tomaslau</h5>
                                        <p class="mb-0 text-muted"><small>Member Since 2017</small></p>
                                    </td>
                                    <td>
                                        <i class="mdi mdi-currency-btc text-primary"></i> BTC
                                    </td>
                                    <td>
                                        0.00816117 BTC
                                    </td>
                                    <td>
                                        0.00097036 BTC
                                    </td>
                                    <td>
                                        <a href="#" class="btn btn-sm btn-custom"><i class="mdi mdi-plus"></i></a>
                                        <a href="#" class="btn btn-sm btn-danger"><i class="mdi mdi-minus"></i></a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <img src="images/7.jpg" alt="contact-img" title="contact-img" class="rounded-circle thumb-sm" />
                                    </td>
                                    <td>
                                        <h5 class="m-0 font-weight-normal">Erwin E. Brown</h5>
                                        <p class="mb-0 text-muted"><small>Member Since 2017</small></p>
                                    </td>
                                    <td>
                                        <i class="mdi mdi-currency-eth text-primary"></i> ETH
                                    </td>
                                    <td>
                                        3.16117008 ETH
                                    </td>
                                    <td>
                                        1.70360009 ETH
                                    </td>
                                    <td>
                                        <a href="#" class="btn btn-sm btn-custom"><i class="mdi mdi-plus"></i></a>
                                        <a href="#" class="btn btn-sm btn-danger"><i class="mdi mdi-minus"></i></a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <img src="images/7.jpg" alt="contact-img" title="contact-img" class="rounded-circle thumb-sm" />
                                    </td>
                                    <td>
                                        <h5 class="m-0 font-weight-normal">Margeret V. Ligon</h5>
                                        <p class="mb-0 text-muted"><small>Member Since 2017</small></p>
                                    </td>
                                    <td>
                                        <i class="mdi mdi-currency-eur text-primary"></i> EUR
                                    </td>
                                    <td>
                                        25.08 EUR
                                    </td>
                                    <td>
                                        12.58 EUR
                                    </td>
                                    <td>
                                        <a href="#" class="btn btn-sm btn-custom"><i class="mdi mdi-plus"></i></a>
                                        <a href="#" class="btn btn-sm btn-danger"><i class="mdi mdi-minus"></i></a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <img src="images/7.jpg" alt="contact-img" title="contact-img" class="rounded-circle thumb-sm" />
                                    </td>
                                    <td>
                                        <h5 class="m-0 font-weight-normal">Jose D. Delacruz</h5>
                                        <p class="mb-0 text-muted"><small>Member Since 2017</small></p>
                                    </td>
                                    <td>
                                        <i class="mdi mdi-currency-cny text-primary"></i> CNY
                                    </td>
                                    <td>
                                        82.00 CNY
                                    </td>
                                    <td>
                                        30.83 CNY
                                    </td>
                                    <td>
                                        <a href="#" class="btn btn-sm btn-custom"><i class="mdi mdi-plus"></i></a>
                                        <a href="#" class="btn btn-sm btn-danger"><i class="mdi mdi-minus"></i></a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <img src="images/7.jpg" alt="contact-img" title="contact-img" class="rounded-circle thumb-sm" />
                                    </td>
                                    <td>
                                        <h5 class="m-0 font-weight-normal">Luke J. Sain</h5>
                                        <p class="mb-0 text-muted"><small>Member Since 2017</small></p>
                                    </td>
                                    <td>
                                        <i class="mdi mdi-currency-btc text-primary"></i> BTC
                                    </td>
                                    <td>
                                        2.00816117 BTC
                                    </td>
                                    <td>
                                        1.00097036 BTC
                                    </td>
                                    <td>
                                        <a href="#" class="btn btn-sm btn-custom"><i class="mdi mdi-plus"></i></a>
                                        <a href="#" class="btn btn-sm btn-danger"><i class="mdi mdi-minus"></i></a>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4">
                    <div class="card-box">
                        <h4 class="m-t-0 header-title">Total Wallet Balance</h4>
                        <div id="morris-line-example" style="height: 350px;" class="mt-4"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- end row -->
</div>
<!-- container -->
</div>
<!-- content -->
<?php include('footer.php') ?>
</body>
</html>